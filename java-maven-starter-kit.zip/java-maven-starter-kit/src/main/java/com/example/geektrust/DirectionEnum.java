package com.example.geektrust;

public class DirectionEnum {

    public enum Direction{
        N,
        E,
        W,
        S,
    }


}
