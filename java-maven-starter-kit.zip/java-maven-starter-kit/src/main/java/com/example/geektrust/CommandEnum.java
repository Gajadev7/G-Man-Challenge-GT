package com.example.geektrust;

public class CommandEnum {

    enum Command{
        SOURCE,
        DESTINATION,
        PRINT_POWER
    }
}
